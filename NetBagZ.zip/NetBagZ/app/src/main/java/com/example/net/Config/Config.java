package com.example.net.Config;

public class Config {

    public static final String Base_Url = "http://192.168.0.11/net_application/clint/";
    public static final String Address_Url = "http://192.168.0.11/net_application/clint/";

}
