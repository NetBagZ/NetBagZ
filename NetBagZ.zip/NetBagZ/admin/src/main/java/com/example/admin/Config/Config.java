/**
 * Copyright (c) 2024 Md. Maharab Hosen. All rights reserved.
 * Author: Md. Maharab Hosen
 */
package com.example.admin.Config;

public class Config {

    public static final String Base_Url = "http://192.168.0.11/net_application/admin/";
}
